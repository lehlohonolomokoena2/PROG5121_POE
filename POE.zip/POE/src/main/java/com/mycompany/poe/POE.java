/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 */

package com.mycompany.poe;

import java.util.ArrayList;
import java.io.FileWriter;
import java.io.IOException;
import javax.swing.JOptionPane;
import java.util.Random;


public class POE {

// Registered user info
    static String registeredUsername;
    static String registeredPassword;
    static String registeredPhone;

    // Message counters
    static int totalMessagesSent = 0;
    static int messageNumber = 0;

    // Message Data Storage
    static ArrayList<String> sentMessages = new ArrayList<>();
    static ArrayList<String> disregardedMessages = new ArrayList<>();
    static ArrayList<String> storedMessages = new ArrayList<>();
    static ArrayList<String> recipients = new ArrayList<>();
    static ArrayList<String> messageIDs = new ArrayList<>();
    static ArrayList<String> messageHashes = new ArrayList<>();

    public static void main(String[] args) {
        JOptionPane.showMessageDialog(null, "Welcome to Quickchat.");
        registerUser();

        if (loginUser()) {
            JOptionPane.showMessageDialog(null, "Login successful.");
            runMainMenu();
        } else {
            JOptionPane.showMessageDialog(null, "Login failed. Exiting.");
        }
    }

    public static void registerUser() {
        boolean valid = false;

        while (!valid) {
            registeredUsername = JOptionPane.showInputDialog("Enter username (_ and max 5 chars):");

            if (!(registeredUsername.contains("_") && registeredUsername.length() <= 5)) {
                JOptionPane.showMessageDialog(null, "Invalid username");
                continue;
            }

            registeredPassword = JOptionPane.showInputDialog("Enter password:");
            if (!registeredPassword.matches("^(?=.*[A-Z])(?=.*\\d)(?=.*[@#$%^&+=!]).{8,}$")) {
                JOptionPane.showMessageDialog(null, "Invalid password");
                continue;
            }

            registeredPhone = JOptionPane.showInputDialog("Enter phone (+27xxxxxxxxx):");
            if (!registeredPhone.matches("^\\+27[6-8]\\d{8}$")) {
                JOptionPane.showMessageDialog(null, "Invalid phone");
                continue;
            }

            valid = true;
            JOptionPane.showMessageDialog(null, "Registration successful!");
        }
    }

    public static boolean loginUser() {
        String user = JOptionPane.showInputDialog("Username:");
        String pass = JOptionPane.showInputDialog("Password:");
        return user.equals(registeredUsername) && pass.equals(registeredPassword);
    }

    public static void runMainMenu() {
        boolean running = true;

        while (running) {
            String[] options = {"Send Messages", "Message Manager", "Quit"};

            int choice = JOptionPane.showOptionDialog(null, "Menu", "Main Menu",
                    JOptionPane.DEFAULT_OPTION, JOptionPane.INFORMATION_MESSAGE,
                    null, options, options[0]);

            switch (choice) {
                case 0 -> sendMessages();
                case 1 -> messageManagerMenu();
                case 2 -> running = false;
                default -> JOptionPane.showMessageDialog(null, "Invalid choice");
            }
        }
    }

    public static void sendMessages() {
        String input = JOptionPane.showInputDialog("How many messages?");
        if (input == null) return;

        int count;
        try {
            count = Integer.parseInt(input);
        } catch (Exception e) {
            JOptionPane.showMessageDialog(null, "Invalid number");
            return;
        }

        for (int i = 0; i < count; i++) {
            messageNumber++;

            String id = generateMessageID();

            String recipient = JOptionPane.showInputDialog("Recipient (+27xxxxxxxxx):");
            if (!recipient.matches("^\\+27\\d{9}$")) {
                JOptionPane.showMessageDialog(null, "Invalid number");
                i--;
                continue;
            }

            String message = JOptionPane.showInputDialog("Enter message (max 250):");
            if (message.length() > 250) {
                JOptionPane.showMessageDialog(null, "Too long");
                i--;
                continue;
            }

            String hash = generateMessageHash(id, messageNumber, message);

            String[] actions = {"Send", "Disregard", "Store"};
            int action = JOptionPane.showOptionDialog(null, "Choose action", "Message",
                    JOptionPane.DEFAULT_OPTION, JOptionPane.INFORMATION_MESSAGE,
                    null, actions, actions[0]);

            switch (action) {
                case 0 -> {
                    totalMessagesSent++;
                    sentMessages.add(message);
                    recipients.add(recipient);
                    messageIDs.add(id);
                    messageHashes.add(hash);

                    displayMessageDetails(id, hash, recipient, message);
                }

                case 1 -> disregardedMessages.add(message);

                case 2 -> {
                    storedMessages.add(message);
                    writeMessageToJSON(id, hash, recipient, message);
                }
            }
        }

        JOptionPane.showMessageDialog(null, "Total sent: " + totalMessagesSent);
    }

    public static void messageManagerMenu() {
        String[] options = {
                "Show Sent Messages",
                "Longest Message",
                "Search by ID",
                "Search by Recipient",
                "Delete by Hash",
                "Report",
                "Back"
        };

        int choice = JOptionPane.showOptionDialog(null, "Manager", "Message Manager",
                JOptionPane.DEFAULT_OPTION, JOptionPane.INFORMATION_MESSAGE,
                null, options, options[0]);

        switch (choice) {
            case 0 -> displayMessages();
            case 1 -> longestMessage();
            case 2 -> searchByID();
            case 3 -> searchByRecipient();
            case 4 -> deleteByHash();
            case 5 -> report();
        }
    }

    // ========= FEATURES =========

    public static void displayMessages() {
        if (sentMessages.isEmpty()) {
            JOptionPane.showMessageDialog(null, "No messages");
            return;
        }

        StringBuilder sb = new StringBuilder();

        for (int i = 0; i < sentMessages.size(); i++) {
            sb.append("ID: ").append(messageIDs.get(i)).append("\n");
            sb.append("Recipient: ").append(recipients.get(i)).append("\n");
            sb.append("Message: ").append(sentMessages.get(i)).append("\n\n");
        }

        JOptionPane.showMessageDialog(null, sb.toString());
    }

    public static void longestMessage() {
        String longest = "";

        for (String msg : sentMessages) {
            if (msg.length() > longest.length()) {
                longest = msg;
            }
        }

        JOptionPane.showMessageDialog(null, longest);
    }

    public static void searchByID() {
        String id = JOptionPane.showInputDialog("Enter ID");

        for (int i = 0; i < messageIDs.size(); i++) {
            if (messageIDs.get(i).equals(id)) {
                JOptionPane.showMessageDialog(null, sentMessages.get(i));
                return;
            }
        }
    }

    public static void searchByRecipient() {
        String rec = JOptionPane.showInputDialog("Enter recipient");

        StringBuilder sb = new StringBuilder();

        for (int i = 0; i < recipients.size(); i++) {
            if (recipients.get(i).equals(rec)) {
                sb.append(sentMessages.get(i)).append("\n");
            }
        }

        JOptionPane.showMessageDialog(null, sb.toString());
    }

    public static void deleteByHash() {
        String hash = JOptionPane.showInputDialog("Enter hash");

        for (int i = 0; i < messageHashes.size(); i++) {
            if (messageHashes.get(i).equals(hash)) {
                sentMessages.remove(i);
                recipients.remove(i);
                messageIDs.remove(i);
                messageHashes.remove(i);

                JOptionPane.showMessageDialog(null, "Deleted");
                return;
            }
        }
    }

    public static void report() {
        StringBuilder sb = new StringBuilder();

        for (int i = 0; i < sentMessages.size(); i++) {
            sb.append(messageIDs.get(i)).append(" - ")
              .append(recipients.get(i)).append(" - ")
              .append(sentMessages.get(i)).append("\n");
        }

        JOptionPane.showMessageDialog(null, sb.toString());
    }

    // ========= HELPERS =========

    public static String generateMessageID() {
        return String.format("%010d", new Random().nextInt(1_000_000_000));
    }

    public static String generateMessageHash(String id, int num, String msg) {
        String[] words = msg.split(" ");
        String first = words[0];
        String last = words[words.length - 1];

        return (id.substring(0, 2) + ":" + num + ":" + first + last).toUpperCase();
    }

    public static void displayMessageDetails(String id, String hash, String recipient, String message) {
        JOptionPane.showMessageDialog(null,
                "ID: " + id +
                "\nHash: " + hash +
                "\nRecipient: " + recipient +
                "\nMessage: " + message);
    }

    public static void writeMessageToJSON(String id, String hash, String recipient, String message) {
        try (FileWriter f = new FileWriter("messages.json", true)) {
            f.write("{\"id\":\"" + id + "\",\"hash\":\"" + hash + "\",\"recipient\":\"" + recipient + "\",\"message\":\"" + message + "\"}\n");
        } catch (IOException e) {
            JOptionPane.showMessageDialog(null, "File error");
        }
    }
}

    
    