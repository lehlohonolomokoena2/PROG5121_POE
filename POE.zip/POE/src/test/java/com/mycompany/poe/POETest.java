/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/UnitTests/JUnit5TestClass.java to edit this template
 */
package com.mycompany.poe;

import org.junit.jupiter.api.AfterEach;
import org.junit.jupiter.api.AfterAll;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.BeforeAll;
import org.junit.jupiter.api.Test;
import static org.junit.jupiter.api.Assertions.*;

/**
 *
 * @author Lehlohonolo.Mokoena
 */
public class POETest {
    
    public POETest() {
    }
    
    @BeforeAll
    public static void setUpClass() {
    }
    
    @AfterAll
    public static void tearDownClass() {
    }
    
    @BeforeEach
    public void setUp() {
    }
    
    @AfterEach
    public void tea    /**
     * Test of main method, of class POE.
     */
    @Test
    public void testMain() {
        System.out.println("main");
        String[] args = null;
        POE.main(args);
        // TODO review the generated test code and remove the default call to fail.
        fail("The test case is a prototype.");
    }

    /**
     * Test of registerUser method, of class POE.
     */
    @Test
    public void testRegisterUser() {
        System.out.println("registerUser");
        POE.registerUser();
        // TODO review the generated test code and remove the default call to fail.
        fail("The test case is a prototype.");
    }

    /**
     * Test of loginUser method, of class POE.
     */
    @Test
    public void testLoginUser() {
        System.out.println("loginUser");
        boolean expResult = false;
        boolean result = POE.loginUser();
        assertEquals(expResult, result);
        // TODO review the generated test code and remove the default call to fail.
        fail("The test case is a prototype.");
    }

    /**
     * Test of runMainMenu method, of class POE.
     */
    @Test
    public void testRunMainMenu() {
        System.out.println("runMainMenu");
        POE.runMainMenu();
        // TODO review the generated test code and remove the default call to fail.
        fail("The test case is a prototype.");
    }

    /**
     * Test of sendMessages method, of class POE.
     */
    @Test
    public void testSendMessages() {
        System.out.println("sendMessages");
        POE.sendMessages();
        // TODO review the generated test code and remove the default call to fail.
        fail("The test case is a prototype.");
    }

    /**
     * Test of messageManagerMenu method, of class POE.
     */
    @Test
    public void testMessageManagerMenu() {
        System.out.println("messageManagerMenu");
        POE.messageManagerMenu();
        // TODO review the generated test code and remove the default call to fail.
        fail("The test case is a prototype.");
    }

    /**
     * Test of displayMessages method, of class POE.
     */
    @Test
    public void testDisplayMessages() {
        System.out.println("displayMessages");
        POE.displayMessages();
        // TODO review the generated test code and remove the default call to fail.
        fail("The test case is a prototype.");
    }

    /**
     * Test of longestMessage method, of class POE.
     */
    @Test
    public void testLongestMessage() {
        System.out.println("longestMessage");
        POE.longestMessage();
        // TODO review the generated test code and remove the default call to fail.
        fail("The test case is a prototype.");
    }

    /**
     * Test of searchByID method, of class POE.
     */
    @Test
    public void testSearchByID() {
        System.out.println("searchByID");
        POE.searchByID();
        // TODO review the generated test code and remove the default call to fail.
        fail("The test case is a prototype.");
    }

    /**
     * Test of searchByRecipient method, of class POE.
     */
    @Test
    public void testSearchByRecipient() {
        System.out.println("searchByRecipient");
        POE.searchByRecipient();
        // TODO review the generated test code and remove the default call to fail.
        fail("The test case is a prototype.");
    }

    /**
     * Test of deleteByHash method, of class POE.
     */
    @Test
    public void testDeleteByHash() {
        System.out.println("deleteByHash");
        POE.deleteByHash();
        // TODO review the generated test code and remove the default call to fail.
        fail("The test case is a prototype.");
    }

    /**
     * Test of report method, of class POE.
     */
    @Test
    public void testReport() {
        System.out.println("report");
        POE.report();
        // TODO review the generated test code and remove the default call to fail.
        fail("The test case is a prototype.");
    }

    /**
     * Test of generateMessageID method, of class POE.
     */
    @Test
    public void testGenerateMessageID() {
        System.out.println("generateMessageID");
        String expResult = "";
        String result = POE.generateMessageID();
        assertEquals(expResult, result);
        // TODO review the generated test code and remove the default call to fail.
        fail("The test case is a prototype.");
    }

    /**
     * Test of generateMessageHash method, of class POE.
     */
    @Test
    public void testGenerateMessageHash() {
        System.out.println("generateMessageHash");
        String id = "";
        int num = 0;
        String msg = "";
        String expResult = "";
        String result = POE.generateMessageHash(id, num, msg);
        assertEquals(expResult, result);
        // TODO review the generated test code and remove the default call to fail.
        fail("The test case is a prototype.");
    }

    /**
     * Test of displayMessageDetails method, of class POE.
     */
    @Test
    public void testDisplayMessageDetails() {
        System.out.println("displayMessageDetails");
        String id = "";
        String hash = "";
        String recipient = "";
        String message = "";
        POE.displayMessageDetails(id, hash, recipient, message);
        // TODO review the generated test code and remove the default call to fail.
        fail("The test case is a prototype.");
    }

    /**
     * Test of writeMessageToJSON method, of class POE.
     */
    @Test
    public void testWriteMessageToJSON() {
        System.out.println("writeMessageToJSON");
        String id = "";
        String hash = "";
        String recipient = "";
        String message = "";
        POE.writeMessageToJSON(id, hash, recipient, message);
        // TODO review the generated test code and remove the default call to fail.
        fail("The test case is a prototype.");
    }

rDown() {
    }
    
}
